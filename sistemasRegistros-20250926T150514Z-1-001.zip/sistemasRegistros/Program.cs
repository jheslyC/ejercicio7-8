﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemasRegistros
{
    internal class Program
    {
       
        static List<string> usuarios = new List<string>();
        static void Main()
        {
            bool salir = false;
            Console.WriteLine("Registro");
            while (salir)
            {
                
                Console.WriteLine("\nRegistro de usuarios");
                Console.WriteLine("1. Ingresar usuario");
                Console.WriteLine("2. Mostrar usuarios");
                Console.WriteLine("3. Salir");

                string opcion = Console.ReadLine();

                
                if(opcion == "1")
                {

                    Console.WriteLine("Ingrese el usuario");
                    string nombre = Console.ReadLine();

                    if (UsuarioExiste(nombre))
                    {
                        Console.WriteLine($"El usuario ´{nombre}´ ya existe");
                    }
                    else
                    {
                        usuarios.Add(nombre);
                        Console.WriteLine("Usuario registrado");
                    }
                }
                else if(opcion == "2")
                {
                    MostrarUsuarios();
                }
                else if(opcion == "3")
                {
                    salir = true;
                }
                else
                {
                    Console.WriteLine("Opcion no valida");
                }

                           
            }
           
        }
        static bool UsuarioExiste(string nombre)
        {
            return usuarios.Contains(nombre);
        }
        static void MostrarUsuarios() 
        {
            if (usuarios.Count == 0)
            {
                Console.WriteLine("No hay usuarios registrados");
            }
            else
            {
                Console.WriteLine("\nUsuarios registrados:");
                foreach(var u in usuarios)
                {
                    Console.WriteLine(u);
                }
            }
        }
      
    }
}
